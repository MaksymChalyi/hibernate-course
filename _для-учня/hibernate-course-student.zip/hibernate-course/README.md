# Mini Bank — курс Hibernate

Протягом курсу ти будуєш backend невеликого онлайн-банку: клієнти, рахунки в різних валютах, перекази, історія операцій, звіти і REST API.

Проєкт уже створений: для кожного модуля є **заготовка** (`starter`). Код у ній компілюється, а місця, які треба дописати, позначені `// TODO 1`, `// TODO 2`, … З нуля нічого створювати не треба.

---

## Що встановити (один раз)

1. **JDK 21** — наприклад, [Eclipse Temurin 21](https://adoptium.net/temurin/releases/?version=21).
2. **IntelliJ IDEA** — Community Edition достатньо: [jetbrains.com/idea/download](https://www.jetbrains.com/idea/download/).
3. **PostgreSQL 16:**
   - **Windows:** інсталятор з [postgresql.org/download/windows](https://www.postgresql.org/download/windows/). Порт залиш 5432, запам'ятай пароль користувача `postgres`. Разом встановиться pgAdmin.
   - **macOS:** [Postgres.app](https://postgresapp.com/) або `brew install postgresql@16` і `brew services start postgresql@16`.
   - **Linux:** `sudo apt install postgresql`.

Docker не потрібен.

---

## Перший запуск

### 1. Створити базу курсу

Виконай файл `setup-local-db.sql` з цієї папки від імені користувача `postgres`.

**Через pgAdmin (Windows):** підключись до сервера → правою кнопкою на `postgres` → **Query Tool** → відкрий `setup-local-db.sql` → **Execute** (F5).

**Через термінал:**
```bash
psql -U postgres -f setup-local-db.sql
```

Результат: база `minibank`, користувач `minibank`, пароль `minibank`.

### 2. Відкрити проєкт в IDEA

**File → Open** → вибери файл `pom.xml` у корені цієї папки → **Open as Project** → **Trust Project**.

Перший раз IDEA завантажує бібліотеки кілька хвилин (прогрес унизу праворуч). Дочекайся завершення.

Якщо IDEA питає про JDK: **File → Project Structure → Project → SDK → 21**.

### 3. Перевірити, що все працює

Відкрий `m01-jdbc-to-hibernate/starter/src/main/java/ua/minibank/JdbcDemo.java` і натисни зелену стрілку біля `main`.
Він створить таблицю і виведе клієнтів, збережених через чистий JDBC. Якщо бачиш рядок «Усі клієнти: [...]» — база і проєкт налаштовані правильно. Останній рядок падає з `TODO 0` — це перше завдання заняття.

`HibernateDemo.java` поруч поки що падає з помилкою. **Так і має бути** — Hibernate ти налаштуєш на першому занятті.

---

## Як працювати з модулем

1. Прочитай лекцію в Notion: спочатку теорія, потім розділ «Практика».
2. Відкрий `starter/ЗАВДАННЯ.md` модуля — там коротка таблиця: номер завдання, файл, що зробити, як перевірити.
3. Знайди завдання в коді: **View → Tool Windows → TODO**.
   - Рядок `// TODO 3 ...` — це завдання 3.
   - Над ним коментар **«Завдання 3»**: що зробити, навіщо, і заготовка коду, яку можна взяти за основу.
4. Роби завдання **по порядку**. Після кожного запускай тести: правою кнопкою на `src/test/java` → **Run 'All Tests'**.
   - Назва тесту починається з номера завдання: «3 · save() …» перевіряє завдання 3.
   - Тести з позначкою «(резерв)» або «(ДЗ)» — для додаткових завдань, на занятті вони можуть лишатися червоними.
   - Якщо бачиш помилку `TODO 3: ...` — завдання 3 ще не зроблене.
5. SQL, який виконує Hibernate, видно в консолі під час запуску.
6. Застряг — у лекції в кінці практики є таблиця «Якщо не працює»: що бачиш → причина.

---

## Розв'язки

Після заняття викладач надсилає архів розв'язку модуля, наприклад `m02-entity-mapping-solution.zip`.

1. Розпакуй його в **корінь** папки `hibernate-course` (туди, де лежить `pom.xml`). Поруч зі `starter` з'явиться папка `solution`:
   ```
   m02-entity-mapping/
   ├── starter/
   └── solution/
   ```
2. У кореневому `pom.xml` розкоментуй рядок `<module>m02-entity-mapping/solution</module>`.
3. В IDEA: вкладка **Maven** (праворуч) → кнопка **Reload All Maven Projects**.

Порівнюй розв'язок зі своїм кодом. Відрізняється — не страшно, головне розуміти, чому зроблено саме так.

---

## Де подивитися таблиці

Будь-який клієнт для PostgreSQL: pgAdmin, [DBeaver](https://dbeaver.io/) або вкладка **Database** в IDEA Ultimate.
Підключення: `localhost:5432`, база `minibank`, користувач і пароль `minibank`.

Кожен модуль працює у своїй схемі: `m01`, `m02`, … Таблиці шукай усередині схеми.

---

## Якщо щось не працює

| Помилка | Що робити |
|---|---|
| `Connection refused` | PostgreSQL не запущений. Windows: «Служби» → `postgresql-x64-16` → Запустити. macOS: відкрий Postgres.app |
| `password authentication failed for user "minibank"` | Не виконано `setup-local-db.sql` |
| `permission denied for database minibank` | Виконай від `postgres`: `alter database minibank owner to minibank;` |
| Червоні імпорти `jakarta.persistence` | IDEA ще не завантажила бібліотеки: вкладка Maven → Reload All Maven Projects |
| `invalid source release: 21` | Проєкт відкрито не з JDK 21: File → Project Structure → SDK |
