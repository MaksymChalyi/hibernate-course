# Додатково 5. Second-level cache: Ehcache і Redis

**Формат:** самостійне читання або окреме заняття 60 + 30 хв після модуля 10.
**Передумови:** модулі 3 (first-level cache), 9 (конкурентність), 10 (вимірювання).

**Мета:** розуміти, коли кеш між сесіями прискорює застосунок, а коли ламає дані, і вміти увімкнути його точково.

---

## Два рівні кешу (5 хв)

| | First-level (модуль 3) | Second-level |
|---|---|---|
| Де живе | У `EntityManager` | У `EntityManagerFactory`, спільний для всіх запитів |
| Скільки живе | Одна операція | Поки працює застосунок (або TTL) |
| Увімкнений | Завжди | Лише явно, потребує провайдера |
| Ризик застарілих даних | Майже немає | **Є** |

Типовий приклад: таблиця тарифів банку (комісія за переказ, ліміти). Читається на кожен переказ, змінюється раз на місяць. Без кешу — SELECT на кожен переказ.

---

## Що можна кешувати і що ні (10 хв)

| ✅ Добре | ❌ Погано |
|---|---|
| Довідники: валюти, країни, тарифи, коди банків | Баланси рахунків |
| Читаються часто, змінюються рідко | Операції (їх багато, кожна читається рідко) |
| Змінюються лише через цей застосунок | Дані, які змінює інший сервіс або SQL-скрипт напряму |
| Застарілість на хвилину некритична | Будь-що, де застаріле значення = помилка в грошах |

**Найважливіше:** кеш не знає про зміни, зроблені **в обхід Hibernate** — native SQL, bulk update (модуль 7), інший сервіс, ручний SQL адміністратора. Після такої зміни кеш віддаватиме старе значення.

Правило: не вмикати кеш «на всякий випадок». Спочатку виміряти (модуль 10), знайти конкретну entity, що читається тисячі разів, і закешувати лише її.

---

## Ehcache через JCache (15 хв)

Залежності:

```xml
<dependency>
    <groupId>org.hibernate.orm</groupId>
    <artifactId>hibernate-jcache</artifactId>
    <version>${hibernate.version}</version>
</dependency>
<dependency>
    <groupId>org.ehcache</groupId>
    <artifactId>ehcache</artifactId>
    <version>3.10.8</version>          <!-- звір актуальну 3.x -->
    <classifier>jakarta</classifier>   <!-- варіант для jakarta.* -->
</dependency>
```

`persistence.xml`:

```xml
<shared-cache-mode>ENABLE_SELECTIVE</shared-cache-mode>   <!-- кешуються лише позначені entity -->
<properties>
    <property name="hibernate.cache.use_second_level_cache" value="true"/>
    <property name="hibernate.cache.region.factory_class" value="jcache"/>
    <property name="hibernate.javax.cache.provider" value="org.ehcache.jsr107.EhcacheCachingProvider"/>
</properties>
```

Entity:

```java
@Entity
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Tariff {
    @Id private String code;              // "TRANSFER_UAH"
    private BigDecimal feePercent;
    private BigDecimal minFee;
}
```

Тепер `em.find(Tariff.class, "TRANSFER_UAH")` у різних `EntityManager` іде в базу лише перший раз. Перевірка — через `Statistics`:

```java
stats.getSecondLevelCacheHitCount();
stats.getSecondLevelCacheMissCount();
```

---

## Стратегії конкурентного доступу (10 хв)

| Стратегія | Коли |
|---|---|
| `READ_ONLY` | Дані ніколи не змінюються (довідник валют). Найшвидша. Зміна → виняток |
| `NONSTRICT_READ_WRITE` | Зміни рідкі, коротке вікно застарілих даних допустиме |
| `READ_WRITE` | Зміни можливі, потрібна узгодженість у межах одного застосунку. М'які блокування в кеші |
| `TRANSACTIONAL` | Лише з JTA і транзакційним провайдером кешу |

---

## Запити і колекції (5 хв)

- **Кеш entity** працює для `find` і завантаження зв'язків за id. JPQL-запит у кеш entity не йде.
- **Кеш запитів** (`hibernate.cache.use_query_cache=true` + підказка `org.hibernate.cacheable`) зберігає список id результату. Інвалідується при **будь-якій** зміні в задіяних таблицях — для таблиць, що часто змінюються, марний.
- **Кеш колекцій** — окрема анотація `@Cache` на полі колекції.

---

## Redis: кеш для кількох екземплярів застосунку (10 хв)

Ehcache в такій конфігурації живе **в пам'яті одного процесу**. Якщо запущено три екземпляри застосунку і один змінив тариф, два інші ще віддають старе значення.

| Варіант | Як | Ціна |
|---|---|---|
| Локальний кеш + короткий TTL | Ehcache, `expiry` 1–5 хв | Вікно застарілих даних |
| Розподілений кеш | Redis через Redisson (`redisson-hibernate`) або Infinispan | Мережевий виклик на кожне звернення до кешу, ще одна система в експлуатації |
| Без кешу Hibernate | Кеш на рівні сервісу (`Map` з TTL, Caffeine) для конкретного довідника | Код кешування пишемо самі, зате він очевидний |

Для невеликого застосунку третій варіант часто найпростіший і найпрозоріший: «закешувати тарифи на 5 хвилин» — десять рядків коду, які видно і легко тестувати.

Розподілений кеш має сенс, коли екземплярів багато, довідник великий і його читання справді видно в метриках.

---

## Практичне завдання (30 хв)

- [ ] Entity `Tariff` і міграція з кількома тарифами.
- [ ] Ehcache + `READ_WRITE` для `Tariff`.
- [ ] Тест: два `find` у різних `EntityManager` → 1 SQL (`getPrepareStatementCount`) і 1 cache hit.
- [ ] Тест-демонстрація проблеми: змінити тариф native SQL-ом → `find` повертає старе значення. Як це виправити? (`emf.getCache().evict(Tariff.class)`)

---

## Контрольні питання

1. Чим second-level cache відрізняється від first-level?
   *Спільний для всіх `EntityManager` фабрики, вмикається явно, ризик застарілих даних.*
2. Чому баланси не кешують?
   *Часто змінюються, застаріле значення — помилка в грошах.*
3. Що станеться з кешем після native UPDATE?
   *Нічого: кеш віддаватиме старе значення до інвалідації.*
4. Чому локальний Ehcache проблемний для трьох екземплярів застосунку?
   *Зміна в одному екземплярі не інвалідує кеш в інших.*

## Джерела

- [Hibernate User Guide: Caching](https://docs.jboss.org/hibernate/orm/6.6/userguide/html_single/Hibernate_User_Guide.html#caching)
- [Ehcache 3 Documentation](https://www.ehcache.org/documentation/3.10/)
- [Redisson: Hibernate cache](https://redisson.org/docs/cache/hibernate/)
