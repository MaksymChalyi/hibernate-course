# Додатково 1. Hibernate Envers: аудит змін

**Формат:** самостійне читання або окреме заняття 60 + 30 хв після модуля 11.
**Передумови:** модулі 3 (dirty checking), 4 (транзакції), 11 (Flyway).
**База для практики:** `m13-final-project/solution`.

**Мета:** уміти відповісти на питання «хто, коли і що змінив» для будь-якого запису, не пишучи історію вручну.

---

## Навіщо (5 хв)

Клієнт дзвонить: «Мені вчора зменшили кредитний ліміт, я цього не робив». Банк мусить показати:

- яким був ліміт до зміни і яким став;
- коли саме змінився;
- хто змінив — оператор, автоматична перевірка ризиків чи сам клієнт.

Для банків, страхових компаній, медичних систем історія змін — часто регуляторна вимога, а не побажання.

**Варіанти реалізації:**

| Підхід | Плюси | Мінуси |
|---|---|---|
| Таблиця історії, яку заповнюємо вручну в сервісі | Повний контроль | Легко забути в одному з місць |
| Тригери в PostgreSQL | Ловлять навіть зміни в обхід застосунку | Логіка в базі, важче тестувати, не знає користувача застосунку |
| **Hibernate Envers** | Автоматично для кожної зміни через Hibernate, історія як entity | Не бачить bulk-операцій і native SQL, подвоює записи |

---

## Як працює (15 хв)

### Підключення

```xml
<dependency>
    <groupId>org.hibernate.orm</groupId>
    <artifactId>hibernate-envers</artifactId>
    <version>${hibernate.version}</version>
</dependency>
```

Версія — та сама, що й `hibernate-core`. Envers підключається автоматично, щойно з'являється в classpath.

### Позначити, що аудіювати

```java
@Entity
@Audited
public class Account {
    @Id private Long id;
    private String number;
    private BigDecimal balance;

    @NotAudited                        // зв'язок не потрапляє в історію
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;
}
```

### Що з'являється в базі

```
revinfo                         accounts_aud
-------------                   ------------------------------------------------
rev  | revtstmp                 id | rev | revtype | number | balance | ...
1    | 1767600000000            1  | 1   | 0       | UA01   | 10000
2    | 1767600500000            1  | 2   | 1       | UA01   | 9750
```

- `revinfo` — одна **ревізія** на транзакцію: номер і час.
- `accounts_aud` — знімок рядка після кожної зміни.
- `revtype`: `0` — створено, `1` — змінено, `2` — видалено.

Envers пише в `_aud`-таблиці в тій самій транзакції, що й основна зміна. Відкат транзакції відкочує й історію.

### Запити до історії

```java
AuditReader reader = AuditReaderFactory.get(em);

// Усі версії рахунку: entity, ревізія, тип зміни
List<Object[]> history = reader.createQuery()
        .forRevisionsOfEntity(Account.class, false, true)
        .add(AuditEntity.id().eq(accountId))
        .addOrder(AuditEntity.revisionNumber().asc())
        .getResultList();

// Яким був рахунок на конкретну ревізію
Account then = reader.find(Account.class, accountId, revisionNumber);
```

---

## Хто змінив: власна ревізія (10 хв)

За замовчуванням ревізія знає лише час. Щоб зберігати користувача:

```java
@Entity
@Table(name = "revinfo")
@RevisionEntity(UserRevisionListener.class)
public class UserRevision extends DefaultRevisionEntity {
    @Column(name = "changed_by", length = 100)
    private String changedBy;
    // getter/setter
}

public class UserRevisionListener implements RevisionListener {
    @Override
    public void newRevision(Object revision) {
        ((UserRevision) revision).setChangedBy(CurrentUser.get());   // напр. з ThreadLocal, заповненого фільтром
    }
}
```

У Servlet-застосунку користувача кладемо в `ThreadLocal` у фільтрі на початку запиту і прибираємо в `finally`. У Spring це зробить Spring Security.

---

## Envers + Flyway (5 хв)

З `hbm2ddl=validate` (модуль 11) Envers **не створить** таблиці сам — їх треба додати міграцією:

```sql
create sequence revinfo_seq start with 1 increment by 50;

create table revinfo (
    rev        integer primary key,
    revtstmp   bigint,
    changed_by varchar(100)
);

create table accounts_aud (
    id       bigint  not null,
    rev      integer not null references revinfo (rev),
    revtype  smallint,
    number   varchar(34),
    currency varchar(3),
    balance  numeric(19, 4),
    version  bigint,               -- @Version теж аудіюється, якщо не позначене @NotAudited
    primary key (id, rev)
);
```

Точні імена й типи колонок зручно підглянути так: тимчасово запустити з `hbm2ddl=create` на порожній схемі і скопіювати DDL з логу.

---

## Компроміси і межі (10 хв)

- **Bulk-операції і native SQL не аудіюються.** `update Account a set a.balance = ...` (модуль 7) пройде повз Envers.
- **Обсяг.** Кожна зміна — ще один INSERT і рядок. Для балансу, що змінюється тисячі разів на день, `_aud` швидко стане найбільшою таблицею.
- **Що аудіювати.** `Transaction` аудіювати немає сенсу: операції й так незмінні, вони самі є історією. Аудит потрібен для того, що **змінюється**: ліміти, статуси, персональні дані клієнта.
- **Запити до історії повільні** на великих таблицях. Стратегія `ValidityAuditStrategy` (`org.hibernate.envers.audit_strategy=org.hibernate.envers.strategy.internal.ValidityAuditStrategy`) додає колонку кінця дії версії і пришвидшує читання ціною повільнішого запису.
- **Персональні дані.** Історія зберігає старі значення — це важливо для вимог про видалення даних (GDPR): видалити клієнта означає подумати і про `_aud`.

---

## Практичне завдання (30–45 хв)

На базі `m13-final-project/solution`:

- [ ] Додати `hibernate-envers` у `pom.xml` модуля.
- [ ] Позначити `Account` анотацією `@Audited`, `customer` — `@NotAudited`.
- [ ] Міграція `V4__audit.sql` з `revinfo` і `accounts_aud`.
- [ ] Ендпоінт `GET /accounts/{id}/history` → список `{revision, changedAt, balance}`.
- [ ] Тест: два перекази з рахунку 1 → в його історії 2 версії. Поясни, чому немає версії «створено» (підказка: демо-рахунок вставлено SQL-міграцією, повз Hibernate).

---

## Контрольні питання

1. Що таке ревізія в Envers і скільки їх на транзакцію?
   *Запис у `revinfo`; одна на транзакцію, що змінила аудійовані entity.*
2. Чому bulk update не з'являється в історії?
   *Він іде повз Persistence Context, і Envers не бачить змінених об'єктів.*
3. Чому `Transaction` не варто аудіювати?
   *Операції незмінні — вони вже є історією.*
4. Як дізнатися, хто зробив зміну?
   *Власна revision entity з `RevisionListener`.*

## Джерела

- [Hibernate User Guide: Envers](https://docs.jboss.org/hibernate/orm/6.6/userguide/html_single/Hibernate_User_Guide.html#envers)
