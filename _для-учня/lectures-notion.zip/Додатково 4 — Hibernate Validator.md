# Додатково 4. Hibernate Validator (Bean Validation)

**Формат:** самостійне читання або окреме заняття 60 + 30 хв після модуля 11.
**Передумови:** модулі 2 (mapping), 11 (DTO, обробка помилок).

**Мета:** описувати правила даних анотаціями, перевіряти їх на вході API і розуміти, як вони взаємодіють з Hibernate.

---

## Що це (5 хв)

**Jakarta Bean Validation** — специфікація анотацій для перевірки даних (`@NotNull`, `@Size`, `@Email`…). **Hibernate Validator** — її реалізація. Це окремий проєкт від Hibernate ORM: працює з будь-якими Java-об'єктами, не лише з entity.

Аналогія: JPA ↔ Hibernate ORM так само, як Bean Validation ↔ Hibernate Validator.

---

## Підключення (5 хв)

```xml
<dependency>
    <groupId>org.hibernate.validator</groupId>
    <artifactId>hibernate-validator</artifactId>
    <version>8.0.2.Final</version>   <!-- звір актуальну 8.x на Maven Central -->
</dependency>
<dependency>
    <!-- реалізація Expression Language: потрібна для повідомлень про помилки -->
    <groupId>org.glassfish.expressly</groupId>
    <artifactId>expressly</artifactId>
    <version>5.0.0</version>
</dependency>
```

Hibernate Validator 8.x відповідає Jakarta Validation 3.0 і підходить до Hibernate ORM 6 і Jakarta EE 10.

---

## Анотації на прикладі переказу (15 хв)

```java
public record TransferRequest(
        @NotNull Long fromAccountId,
        @NotNull Long toAccountId,
        @NotNull
        @Positive
        @Digits(integer = 15, fraction = 2)     // не більше копійок
        BigDecimal amount) {
}

public record OpenAccountRequest(
        @NotBlank @Pattern(regexp = "UA\\d{27}", message = "Некоректний IBAN") String number,
        @NotNull CurrencyCode currency) {
}
```

Часто вживані:

| Анотація | Перевіряє |
|---|---|
| `@NotNull` | Не `null` |
| `@NotBlank` | Рядок не `null` і не з самих пробілів |
| `@Size(min, max)` | Довжина рядка / розмір колекції |
| `@Positive`, `@PositiveOrZero` | Число > 0 / ≥ 0 |
| `@Digits(integer, fraction)` | Кількість цифр до і після коми |
| `@Email`, `@Pattern` | Формат |
| `@Past`, `@Future` | Дата в минулому / майбутньому |

Ручна перевірка (без Spring):

```java
Validator validator = Validation.buildDefaultValidatorFactory().getValidator();   // один на застосунок
Set<ConstraintViolation<TransferRequest>> violations = validator.validate(request);
if (!violations.isEmpty()) {
    throw new ValidationException(violations);   // → HTTP 400 з полями й повідомленнями
}
```

Відповідь API:

```json
{
  "error": "VALIDATION_FAILED",
  "fields": { "amount": "має бути більше 0" }
}
```

У Spring це робить `@Valid` на параметрі контролера.

---

## Bean Validation і Hibernate ORM (10 хв)

Якщо Hibernate Validator є в classpath, Hibernate ORM:

1. **Перевіряє entity перед INSERT і UPDATE.** Порушення → `ConstraintViolationException` до SQL.
2. **Враховує анотації при генерації схеми** (`hbm2ddl`): `@NotNull` → `not null`, `@Size(max = 100)` → `varchar(100)`.

Керується параметром `jakarta.persistence.validation.mode`: `AUTO` (за замовчуванням: увімкнено, якщо є провайдер), `CALLBACK` (обов'язково, помилка без провайдера), `NONE`.

---

## Де перевіряти: DTO, entity чи база (15 хв)

| Рівень | Що перевіряти | Приклад |
|---|---|---|
| **DTO на вході API** | Формат вхідних даних, обов'язкові поля | `amount > 0`, IBAN за шаблоном |
| **Entity / доменні методи** | Бізнес-правила, що залежать від стану | `Account.debit`: не піти в мінус |
| **База (constraints)** | Останній рубіж цілісності | `not null`, `unique`, `foreign key`, `check (balance >= 0)` |

- Bean Validation — для **форми** даних. Правило «на рахунку достатньо коштів» залежить від стану бази — це не анотація, а метод `debit` (модуль 4).
- Анотації на entity і DTO можуть дублюватися — це нормально: різні межі системи.
- Обмеження в базі **не замінюються** анотаціями: дані можуть прийти в обхід застосунку (міграція, ручний SQL, інший сервіс).

---

## Власне правило (10 хв)

```java
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DifferentAccountsValidator.class)
public @interface DifferentAccounts {
    String message() default "Не можна переказати кошти на той самий рахунок";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}

public class DifferentAccountsValidator implements ConstraintValidator<DifferentAccounts, TransferRequest> {
    @Override
    public boolean isValid(TransferRequest r, ConstraintValidatorContext ctx) {
        return r.fromAccountId() == null || !r.fromAccountId().equals(r.toAccountId());
    }
}

@DifferentAccounts
public record TransferRequest(...) { }
```

---

## Практичне завдання (30 хв)

На базі `m13-final-project/solution`:

- [ ] Додати залежності.
- [ ] Анотації на `TransferRequest`, `@DifferentAccounts`.
- [ ] Валідація в `TransferServlet` до виклику сервісу; відповідь 400 з полями.
- [ ] Прибрати з `TransferService` перевірки, які тепер дублюються анотаціями? Обговори: чи варто. (Підказка: сервіс можуть викликати не лише з HTTP.)
- [ ] Тест: `amount = 0.001` → 400 з полем `amount`.

---

## Контрольні питання

1. Чим Hibernate Validator відрізняється від Hibernate ORM?
   *Окрема бібліотека, реалізація Bean Validation; працює з будь-якими об'єктами.*
2. Чому «достатньо коштів» не перевіряють анотацією?
   *Правило залежить від стану бази, а не від форми даних.*
3. Що станеться з entity з `@NotNull`-полем = `null` при `persist`, якщо валідатор є в classpath?
   *`ConstraintViolationException` до виконання SQL.*
4. Чи можна прибрати `not null` з бази, якщо є `@NotNull`?
   *Ні: база захищає від змін в обхід застосунку.*

## Джерела

- [Hibernate Validator 8.0 Reference Guide](https://docs.jboss.org/hibernate/validator/8.0/reference/en-US/html_single/)
- [Jakarta Validation 3.0](https://jakarta.ee/specifications/bean-validation/3.0/)
