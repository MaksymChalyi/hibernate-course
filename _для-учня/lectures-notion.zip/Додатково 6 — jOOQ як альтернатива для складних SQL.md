# Додатково 6. jOOQ як альтернатива для складних SQL-запитів

**Формат:** самостійне читання або окреме заняття 60 + 30 хв після модуля 7.
**Передумови:** модуль 7 (JPQL, Criteria, native SQL).

**Мета:** розуміти, коли SQL-first підхід кращий за ORM, і як jOOQ поєднується з Hibernate в одному проєкті.

---

## Проблема (5 хв)

У модулі 7 звіт із window function довелося писати native SQL-рядком:

```java
em.createNativeQuery("""
        select t.id, t.amount,
               sum(case when t.type = 'CREDIT' then t.amount else -t.amount end)
                   over (order by t.created_at, t.id) as balance_after
        from transactions t join accounts a on a.id = t.account_id
        where a.number = :number
        """)
```

Мінуси: друкарська помилка в імені колонки виявиться лише під час виконання; результат — `Object[]`; перейменування колонки в міграції не підсвітить жодного місця в коді.

---

## Що таке jOOQ (10 хв)

jOOQ — бібліотека, яка дає **типобезпечний SQL у Java**. Підхід протилежний ORM:

| | Hibernate (ORM) | jOOQ (SQL-first) |
|---|---|---|
| Центр моделі | Java-класи (entity) | Схема бази |
| Що пишемо | Об'єкти і JPQL | SQL, але Java-кодом |
| Persistence Context, dirty checking, lazy loading | Є | Немає |
| Складні звіти, window functions, CTE | Native SQL-рядки | Повна підтримка, перевірка компілятором |
| Збереження графа об'єктів з cascade | Сильна сторона | Вручну |

**Генерація коду зі схеми.** Плагін jOOQ читає базу (або міграції Flyway) і генерує класи таблиць:

```java
TRANSACTIONS.ID, TRANSACTIONS.AMOUNT, TRANSACTIONS.CREATED_AT, ACCOUNTS.NUMBER ...
```

Перейменували колонку в міграції → перегенерували код → компілятор показує всі місця, які треба виправити.

**Ліцензія:** безкоштовна Open Source Edition підтримує open-source бази, включно з PostgreSQL. Комерційні бази (Oracle, SQL Server) — платні редакції.

---

## Той самий звіт на jOOQ (15 хв)

```java
DSLContext db = DSL.using(dataSource, SQLDialect.POSTGRES);

var signedAmount = when(TRANSACTIONS.TYPE.eq("CREDIT"), TRANSACTIONS.AMOUNT)
        .otherwise(TRANSACTIONS.AMOUNT.neg());

List<BalancePoint> points = db
        .select(TRANSACTIONS.ID,
                TRANSACTIONS.AMOUNT,
                sum(signedAmount).over(orderBy(TRANSACTIONS.CREATED_AT, TRANSACTIONS.ID)).as("balance_after"))
        .from(TRANSACTIONS)
        .join(ACCOUNTS).on(ACCOUNTS.ID.eq(TRANSACTIONS.ACCOUNT_ID))
        .where(ACCOUNTS.NUMBER.eq(accountNumber))
        .orderBy(TRANSACTIONS.CREATED_AT, TRANSACTIONS.ID)
        .fetch(r -> new BalancePoint(r.value1(), r.value2(), r.value3()));
```

- Код читається як SQL.
- `TRANSACTIONS.AMOUNT` має тип `Field<BigDecimal>`: порівняти його з рядком компілятор не дасть.
- Результат одразу в record, без `Object[]`.

Динамічні фільтри (як Criteria у модулі 7) — природніше:

```java
Condition where = ACCOUNTS.NUMBER.eq(number);
if (filter.type() != null)      where = where.and(TRANSACTIONS.TYPE.eq(filter.type().name()));
if (filter.minAmount() != null) where = where.and(TRANSACTIONS.AMOUNT.ge(filter.minAmount()));
```

---

## Hibernate + jOOQ в одному проєкті (15 хв)

Це не «або-або». Поширений поділ:

| Задача | Інструмент |
|---|---|
| Команди: переказ, відкриття рахунку, зміна ліміту (граф об'єктів, бізнес-правила, транзакції, блокування) | Hibernate |
| Читання: звіти, дашборди, експорт, складні фільтри | jOOQ |
| Масові операції (імпорт, перерахунок) | jOOQ або JDBC batch |

Що треба врахувати:

- **Одна транзакція.** jOOQ і Hibernate мають використовувати те саме з'єднання, якщо їхні зміни мають бути атомарними. Без Spring: взяти з'єднання через `em.unwrap(Session.class).doWork(connection -> DSL.using(connection, ...))`.
- **Persistence Context не бачить змін jOOQ** — як і bulk update у модулі 7.
- **Дві моделі даних** (entity і згенеровані класи) треба тримати синхронними зі схемою. Flyway як єдине джерело правди про схему, генерація jOOQ з міграцій.

---

## Коли jOOQ, а коли достатньо native SQL (5 хв)

- Кілька складних звітів → native SQL у Hibernate достатньо, як у модулі 7.
- Десятки звітів, аналітичний модуль, часті зміни схеми → jOOQ окупиться.
- Застосунок переважно звітний, а не транзакційний → можна обійтися jOOQ без Hibernate взагалі.

Ціна jOOQ: ще одна залежність, крок генерації коду в збірці, ще одна модель даних для команди.

---

## Практичне завдання (45 хв)

- [ ] Новий модуль на базі `m07-queries/solution`: додати jOOQ і плагін генерації `jooq-codegen-maven`, генерувати з локальної бази (схема `m07`).
- [ ] Переписати `runningBalance` і `topCustomersBySpending` на jOOQ.
- [ ] Порівняти з native-версією: кількість рядків, що перевіряє компілятор, що буде при перейменуванні колонки `created_at`.

---

## Контрольні питання

1. Чим SQL-first підхід відрізняється від ORM?
   *Центр моделі — схема бази і SQL, а не Java-об'єкти.*
2. Що дає генерація коду зі схеми?
   *Помилки в іменах і типах колонок ловить компілятор.*
3. Як поділити відповідальність між Hibernate і jOOQ?
   *Hibernate — команди над графом об'єктів, jOOQ — звіти і складні читання.*
4. Що станеться з Persistence Context після UPDATE через jOOQ?
   *Завантажені entity лишаться зі старими значеннями.*

## Джерела

- [jOOQ Manual](https://www.jooq.org/doc/latest/manual/)
- [jOOQ: Code generation](https://www.jooq.org/doc/latest/manual/code-generation/)
- [jOOQ Licensing](https://www.jooq.org/legal/licensing)
