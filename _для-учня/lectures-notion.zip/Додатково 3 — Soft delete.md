# Додатково 3. Soft delete: видалення без видалення

**Формат:** самостійне читання або коротке заняття 60 хв після модуля 7.
**Передумови:** модулі 5 (зв'язки, cascade), 7 (запити).

**Мета:** розуміти, коли «м'яке» видалення доречне, як його робить Hibernate і які проблеми воно створює.

---

## Що це (5 хв)

**Hard delete:** `DELETE FROM cards WHERE id = 7` — рядка більше немає.
**Soft delete:** рядок лишається, але позначений як видалений: `UPDATE cards SET deleted = true WHERE id = 7`. Застосунок його не показує.

Навіщо: відновити помилково видалене, зберегти історію, не ламати зовнішні ключі (картка → операції по картці).

---

## Спершу питання: чи це справді «видалення»? (10 хв)

У модулі 5 ми вирішили, що рахунок у банку **не видаляють, а закривають**. Це не soft delete, а **бізнес-статус**:

```java
public enum AccountStatus { ACTIVE, BLOCKED, CLOSED }
```

| | Бізнес-статус | Soft delete |
|---|---|---|
| Що означає | Подія в житті сутності, має бізнес-зміст | «Ніби видалили» |
| Хто бачить | Закритий рахунок видно в історії клієнта, у звітах | Видалений запис не бачить ніхто |
| Правила | Різні дії в різних статусах | Одне правило: приховати |

Правило: якщо у «видалення» є бізнес-назва (закрити, заблокувати, скасувати, архівувати) — це статус, а не soft delete. Soft delete доречний для того, що справді видаляють, але хочуть мати змогу відновити: збережені шаблони переказів, нотатки, теги.

---

## `@SoftDelete` у Hibernate (15 хв)

З Hibernate 6.4 є вбудована анотація:

```java
@Entity
@SoftDelete                        // колонка deleted (boolean) за замовчуванням
public class TransferTemplate {
    @Id private Long id;
    private String name;
    private Long fromAccountId;
    private Long toAccountId;
    private BigDecimal amount;
}
```

Hibernate:

- `em.remove(template)` перетворює на `UPDATE transfer_template SET deleted = true WHERE id = ?`;
- до кожного запиту додає `where deleted = false`;
- працює і для колекцій.

Варіанти колонки:

```java
@SoftDelete(columnName = "archived")
@SoftDelete(strategy = SoftDeleteType.ACTIVE)   // колонка active: true = не видалено
```

Що анотація **не** дає: дату видалення і хто видалив. Якщо це потрібно — власна колонка `deleted_at timestamp` і `@SQLDelete` + `@SQLRestriction`:

```java
@Entity
@SQLDelete(sql = "update transfer_templates set deleted_at = now() where id = ?")
@SQLRestriction("deleted_at is null")
public class TransferTemplate { ... }
```

---

## Проблеми soft delete (15 хв)

**1. Унікальні обмеження.** Користувач видалив шаблон «Оренда» і створює новий з тією самою назвою — `unique (customer_id, name)` не дасть, бо старий рядок фізично є. Рішення в PostgreSQL — частковий унікальний індекс:

```sql
create unique index uq_template_name on transfer_templates (customer_id, name) where deleted = false;
```

**2. Native SQL і звіти.** Умову `deleted = false` Hibernate додає лише у свої запити. Native-запит, JDBC, BI-інструмент побачать «видалені» дані.

**3. Зовнішні ключі.** Видалений батько з невидаленими дітьми: що показувати? Soft delete не каскадується автоматично так, як `ON DELETE CASCADE`.

**4. Розмір таблиць.** Записи ніколи не зникають. Потрібна окрема процедура остаточного видалення старих записів.

**5. Персональні дані.** Якщо користувач вимагає видалити свої дані, soft delete цього не виконує: дані лишаються в базі.

---

## Практичне завдання (20 хв)

- [ ] Entity `TransferTemplate` (збережений шаблон переказу) з `@SoftDelete` у новому модулі або на базі `m13-final-project/solution`.
- [ ] Тест: після `remove` запит `select t from TransferTemplate t` не повертає шаблон, а native `select count(*) from transfer_templates` — повертає.
- [ ] Частковий унікальний індекс на назву шаблону і тест, що назву можна використати повторно після видалення.
- [ ] Письмово: чому `Account` не підходить для `@SoftDelete`?

---

## Контрольні питання

1. Чим бізнес-статус відрізняється від soft delete?
   *Статус має бізнес-зміст і видимий; soft delete лише приховує.*
2. Яку SQL-команду виконує `em.remove` для entity з `@SoftDelete`?
   *`UPDATE ... SET deleted = true`.*
3. Як зберегти унікальність назви серед невидалених записів?
   *Частковий унікальний індекс `where deleted = false`.*
4. Чи виконує soft delete вимогу «видалити мої персональні дані»?
   *Ні: дані фізично лишаються в базі.*

## Джерела

- [Hibernate User Guide: Soft delete](https://docs.jboss.org/hibernate/orm/6.6/userguide/html_single/Hibernate_User_Guide.html#soft-delete)
- [PostgreSQL: Partial Indexes](https://www.postgresql.org/docs/16/indexes-partial.html)
