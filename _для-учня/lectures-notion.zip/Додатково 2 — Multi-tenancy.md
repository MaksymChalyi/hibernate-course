# Додатково 2. Multi-tenancy: кілька клієнтів-організацій в одному застосунку

**Формат:** самостійне читання або окреме заняття 60 + 30 хв після модуля 11.
**Передумови:** модулі 6 (запити), 11 (веб-застосунок, Flyway).

**Мета:** розуміти три стратегії multi-tenancy, їхню ціну і ризики, і вміти увімкнути найпростішу в Hibernate.

---

## Задача (5 хв)

Mini Bank перетворюється на **SaaS-платформу**: одна інсталяція застосунку обслуговує кілька невеликих банків або кредитних спілок. Кожна організація — **tenant**. Головна вимога: клієнт банку «А» ніколи не побачить даних банку «Б».

Аналогія: багатоквартирний будинок. Tenant — квартира. Питання лише в тому, наскільки товсті стіни.

---

## Три стратегії (20 хв)

| | Окрема база на tenant | Окрема схема на tenant | Колонка `tenant_id` |
|---|---|---|---|
| Ізоляція даних | Найсильніша | Сильна | Лише в коді |
| Вартість на tenant | Найвища | Середня | Майже нульова |
| Скільки tenant витримує | Десятки | Сотні | Тисячі і більше |
| Міграції | По кожній базі | По кожній схемі | Одна |
| Бекап / видалення одного tenant | Легко | Легко | Складно (`delete ... where tenant_id`) |
| Ризик витоку даних | Мінімальний | Низький | **Забутий фільтр = витік** |
| Hibernate | `MultiTenantConnectionProvider` | `MultiTenantConnectionProvider` | `@TenantId` |

**Як обирати:**

- Великі клієнти з вимогами регулятора, можливо з окремими серверами → окрема база.
- Десятки-сотні організацій середнього розміру → окрема схема.
- Багато дрібних tenant, однакові вимоги → колонка `tenant_id`.

Для B2B SaaS з одним розробником старт зазвичай — колонка `tenant_id`: найдешевше в експлуатації. Ізоляцію тоді забезпечують **кілька рівнів захисту**, а не один.

---

## Колонка `tenant_id` з `@TenantId` (15 хв)

```java
@Entity
public class Account {
    @Id private Long id;

    @TenantId
    @Column(name = "tenant_id", nullable = false, updatable = false)
    private String tenantId;

    private String number;
    private BigDecimal balance;
}
```

Hibernate:

- при `persist` сам заповнює `tenant_id` поточним tenant;
- у **кожен** запит до `Account` додає умову `where tenant_id = ?`, включно з JPQL і завантаженням зв'язків.

Звідки Hibernate знає поточний tenant:

```java
public class RequestTenantResolver implements CurrentTenantIdentifierResolver<String> {
    @Override
    public String resolveCurrentTenantIdentifier() {
        return CurrentTenant.get();          // ThreadLocal, заповнений фільтром з токена/піддомену
    }

    @Override
    public boolean validateExistingCurrentSessions() {
        return true;
    }
}
```

```xml
<property name="hibernate.tenant_identifier_resolver" value="ua.minibank.tenancy.RequestTenantResolver"/>
```

Або явно при відкритті сесії:

```java
Session session = emf.unwrap(SessionFactory.class)
        .withOptions()
        .tenantIdentifier("bank-a")
        .openSession();
```

> У Hibernate до 6.4 інтерфейс `CurrentTenantIdentifierResolver` не мав generic-параметра. Для курсу (Hibernate 6.6) — версія з `<String>`.

---

## Де фільтр **не** спрацює (10 хв)

`@TenantId` захищає запити, які генерує Hibernate. Він **не** захищає:

- native SQL (модуль 7) — умову `tenant_id` треба писати вручну;
- bulk update/delete — перевірити поведінку на своїй версії і писати умову явно;
- JDBC-код поруч із Hibernate (модуль 10, `JdbcBatchImporter`);
- кеш: ключі кешу мають включати tenant.

**Другий рівень захисту — Row-Level Security у PostgreSQL:**

```sql
alter table accounts enable row level security;
create policy tenant_isolation on accounts
    using (tenant_id = current_setting('app.tenant_id'));
```

Застосунок на початку транзакції виконує `set local app.tenant_id = 'bank-a'`, і навіть native-запит без умови не побачить чужих рядків. Ціна — ще одне налаштування, яке треба тестувати.

**Третій рівень — тести:** тест, що створює дані двох tenant і перевіряє, що кожен ендпоінт повертає лише свої.

---

## Окрема схема на tenant (коротко, 5 хв)

```java
public class SchemaPerTenantConnectionProvider implements MultiTenantConnectionProvider<String> {
    @Override
    public Connection getConnection(String tenant) throws SQLException {
        Connection c = dataSource.getConnection();
        c.setSchema(tenant);                 // "bank_a"
        return c;
    }
    @Override
    public void releaseConnection(String tenant, Connection c) throws SQLException {
        c.setSchema("public");               // обов'язково: з'єднання повертається в пул
        c.close();
    }
    // ...
}
```

Головна складність не в Hibernate, а в експлуатації: Flyway треба запускати для кожної схеми, створювати схему для нового tenant, моніторити сотні схем.

---

## Практичне завдання (45 хв)

На базі `m13-final-project/solution`:

- [ ] Колонка `tenant_id` у `accounts` і `transactions` (міграція), `@TenantId` в entity.
- [ ] `CurrentTenant` на `ThreadLocal`, заповнення із заголовка `X-Tenant-Id` у servlet-фільтрі, очищення в `finally`.
- [ ] `CurrentTenantIdentifierResolver`, підключений у `persistence.xml`.
- [ ] Тест: рахунок tenant `bank-a` недоступний з `X-Tenant-Id: bank-b` (очікуємо 404).
- [ ] Знайти в проєкті всі native-запити і перевірити, чи вони захищені.

---

## Контрольні питання

1. Коли окрема база на tenant виправдана?
   *Великі клієнти, вимоги регулятора або окремих серверів; невелика кількість tenant.*
2. Що найризикованіше в стратегії з колонкою `tenant_id`?
   *Запит без фільтра — витік даних між tenant.*
3. Які запити `@TenantId` не захищає?
   *Native SQL, JDBC поза Hibernate, частково bulk-операції.*
4. Навіщо скидати схему при поверненні з'єднання в пул?
   *Інакше наступний запит іншого tenant отримає з'єднання з чужою схемою.*

## Джерела

- [Hibernate User Guide: Multitenancy](https://docs.jboss.org/hibernate/orm/6.6/userguide/html_single/Hibernate_User_Guide.html#multitenacy)
- [PostgreSQL: Row Security Policies](https://www.postgresql.org/docs/16/ddl-rowsecurity.html)
